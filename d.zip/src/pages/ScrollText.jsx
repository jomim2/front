import React from "react";
import { useEffect, useState } from "react";
import "./ScrollText.css";

const ScrollText = () => {
  return <div className="scrollText"></div>;
};

export default ScrollText;
